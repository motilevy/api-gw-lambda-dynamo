import os
import boto3
import json
from boto3.dynamodb.conditions import Key, Attr


def put(table, artist, song):
    try:
        r = table.put_item(
            Item={
                'artist': artist,
                'song': song
            }
        )
        print("PutItem succeeded:")
        print(json.dumps(r, indent=4))
    except Exception as e:
        print(e)

def delete(table, artist, song):
    try:
        r = table.delete_item(
            Key={
                'artist': artist,
                'song': song
            },
            ConditionExpression="song = :val",
            ExpressionAttributeValues= {
                ":val": song
            }
        )
        print("DeleteItem succeeded:")
        print(json.dumps(r, indent=4))
    except Exception as e:
        print(e)


def lambda_handler(event, context):
    table_name = os.environ['TABLE']
    dynamodb_client = boto3.client('dynamodb')
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table(table_name)
    try:
        artist=event['artist']
        song=event['song']
        new_song=event['new_song']
    except KeyError:
        print('an artist, current song and new song must be provided')
        raise
    delete(table, artist, song)
    put(table, artist, new_song)

